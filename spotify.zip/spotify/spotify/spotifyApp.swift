//
//  spotifyApp.swift
//  spotify
//
//  Created by Turma02-1 on 07/04/25.
//

import SwiftUI

@main
struct spotifyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

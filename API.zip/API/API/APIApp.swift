import SwiftUI

@main
struct APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

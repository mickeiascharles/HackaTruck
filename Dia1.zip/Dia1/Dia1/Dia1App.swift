//
//  Dia1App.swift
//  Dia1
//
//  Created by Turma02-1 on 04/04/25.
//

import SwiftUI

@main
struct Dia1App: App {
    var body: some Scene {
        WindowGroup{
            ContentView()
        }
    }
}

//
//  ListaView.swift
//  Dia2
//
//  Created by Turma02-1 on 05/04/25.
//

import SwiftUI

struct ListaView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ListaView()
}
